# nixos-ai-lab

NixOS 26.05 headless, Btrfs/Disko, prepared for Incus and local inference.

## Critical warning

`hosts/ai-lab/disko.nix` targets `/dev/nvme0n1` and **will wipe the entire SSD when Disko is executed**. The current files do not execute Disko automatically.

## First stage (no destructive commands)

From the minimal NixOS installer, connected to Wi-Fi:

```sh
nix --extra-experimental-features 'nix-command flakes' flake show --no-write-lock-file .
```

If checking a local Git checkout, Nix flakes see only Git-tracked files. The `flake.lock` is not included and can be generated with `nix flake lock` before installing. Pin and review the resulting lock file.

## After review and explicit disk confirmation

We will run Disko and `nixos-install` together, then assign a password to the `eric` account before reboot. Until then, do **not** run Disko or change partitions.

Wi-Fi connections from the installer are not automatically inherited by the installed system. We will configure Wi-Fi on first boot locally.

No private keys, Wi-Fi credentials, or cloud tokens belong in this public repository.
