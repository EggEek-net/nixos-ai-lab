{ pkgs, ... }: {
  # Minimal first boot. NVIDIA and Incus will be configured after installation.
  system.stateVersion = "26.05";

  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;
  boot.initrd.availableKernelModules = [ "nvme" "xhci_pci" "usbhid" "sd_mod" ];
  boot.kernelPackages = pkgs.linuxPackages;

  networking.hostName = "ai-lab";
  networking.networkmanager.enable = true;

  time.timeZone = "Europe/Paris";
  i18n.defaultLocale = "fr_FR.UTF-8";
  console.keyMap = "fr";

  services.openssh.enable = true;
  services.openssh.settings.PermitRootLogin = "no";
  services.openssh.settings.PasswordAuthentication = true;

  users.users.eric = {
    isNormalUser = true;
    extraGroups = [ "wheel" "networkmanager" ];
  };
  security.sudo.wheelNeedsPassword = true;

  zramSwap = {
    enable = true;
    memoryPercent = 25;
  };

  environment.systemPackages = with pkgs; [
    git vim curl wget htop btop pciutils usbutils
  ];
  nix.settings.experimental-features = [ "nix-command" "flakes" ];
}
